import { FunctionComponent, useCallback } from "react";
import styles from "./Success.module.css";

const Success: FunctionComponent = () => {
  const onFrameContainerClick = useCallback(() => {
    // Please sync "ORDER" to the project
  }, []);

  return (
    <div className={styles.success}>
      <div className={styles.successIconParent} onClick={onFrameContainerClick}>
        <div className={styles.successIcon}>
          <div className={styles.successIconChild} />
          <img
            className={styles.successIconItem}
            alt=""
            src="/vector-41@2x.png"
          />
        </div>
        <b className={styles.success1}>Success</b>
        <div className={styles.thankYouFor1}>{`Thank you for Shopping `}</div>
        <div className={styles.button}>
          <b className={styles.backToOrder1}>Back To Order</b>
        </div>
      </div>
      <div className={styles.successChild} />
      <b className={styles.am}>10:43 AM</b>
      <img className={styles.wifiIcon1} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon1} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon1} alt="" src="/battery@2x.png" />
    </div>
  );
};

export default Success;
