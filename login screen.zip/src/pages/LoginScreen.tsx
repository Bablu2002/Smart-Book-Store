import { FunctionComponent, useCallback } from "react";
import styles from "./LoginScreen.module.css";

const LoginScreen: FunctionComponent = () => {
  const onButtonContainerClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onButtonContainer1Click = useCallback(() => {
    // Please sync "Sign up Screen" to the project
  }, []);

  return (
    <div className={styles.loginScreen}>
      <img className={styles.image1Icon} alt="" src="/image-1@2x.png" />
      <div className={styles.loginScreenChild} />
      <div className={styles.button} onClick={onButtonContainerClick}>
        <b className={styles.logIn}>Log in</b>
      </div>
      <div className={styles.button1} onClick={onButtonContainer1Click}>
        <b className={styles.logIn}>Sign up</b>
      </div>
      <div className={styles.inputFrame2}>
        <div className={styles.logIn}>Password</div>
      </div>
      <div className={styles.inputFrame1}>
        <div className={styles.logIn}>
          Phone number, username or email address
        </div>
      </div>
      <b className={styles.smartBookStore}>Smart Book Store</b>
      <b className={styles.forgetPassword}>Forget Password?</b>
      <div className={styles.groupParent}>
        <div className={styles.lineParent}>
          <div className={styles.groupChild} />
          <div className={styles.groupItem} />
        </div>
        <div className={styles.or}>OR</div>
      </div>
      <b className={styles.dontHaveAccount}>Don’t have account?</b>
    </div>
  );
};

export default LoginScreen;
