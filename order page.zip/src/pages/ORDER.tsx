import { FunctionComponent, useCallback } from "react";
import styles from "./ORDER.module.css";

const ORDER: FunctionComponent = () => {
  const onSystemIcon24pxTrashClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onArrowArrowLeft2Click = useCallback(() => {
    // Please sync "Purchasing page" to the project
  }, []);

  return (
    <div className={styles.order}>
      <div className={styles.inputParent}>
        <div className={styles.input}>
          <div className={styles.fullName}>Full Name</div>
        </div>
        <div className={styles.input}>
          <div className={styles.fullName}>Mobile number</div>
        </div>
        <div className={styles.input2}>
          <div className={styles.fullName}>Postal Code</div>
        </div>
        <div className={styles.input2}>
          <div className={styles.houseNumberApartment}>
            House Number, Apartment, Building, Flat No, Land Mark
          </div>
        </div>
        <div className={styles.input4}>
          <div className={styles.citytownParent}>
            <div className={styles.fullName}>City/Town</div>
            <img className={styles.frameChild} alt="" src="/group-24@2x.png" />
          </div>
          <div className={styles.stateParent}>
            <div className={styles.fullName}>State</div>
            <img className={styles.frameChild} alt="" src="/group-24@2x.png" />
          </div>
        </div>
      </div>
      <b className={styles.addDeliveryAddress}>ADD Delivery Address</b>
      <div className={styles.orderChild} />
      <div className={styles.bookPriceParent}>
        <div className={styles.bookPrice}>
          <b className={styles.deliveryCharges}>Book Price</b>
          <b className={styles.b}>$4.63</b>
        </div>
        <div className={styles.bookPrice}>
          <b className={styles.deliveryCharges}>{`Delivery Charges `}</b>
          <b className={styles.b}>¢0.24</b>
        </div>
        <div className={styles.bookPrice}>
          <b className={styles.deliveryCharges}>Total</b>
          <b className={styles.b}>$4.87</b>
        </div>
      </div>
      <div className={styles.orderItem} />
      <div className={styles.item}>
        <div className={styles.deliveryCharges}>
          <p className={styles.abandonedKingdom}>
            <b>Abandoned Kingdom</b>
          </p>
          <p className={styles.claudiaWilson}>{`Claudia Wilson `}</p>
        </div>
        <div className={styles.buttoninputNumberParent}>
          <div className={styles.buttoninputNumber}>
            <img
              className={styles.buttoninputNumberChild}
              alt=""
              src="/rectangle-430@2x.png"
            />
            <div className={styles.buttoninputNumberItem} />
            <img
              className={styles.buttoninputNumberInner}
              alt=""
              src="/rectangle-432@2x.png"
            />
            <b className={styles.b3}>1</b>
            <img
              className={styles.systemIcon16pxplus}
              alt=""
              src="/system-icon16pxplus@2x.png"
            />
            <img
              className={styles.systemIcon16pxminus}
              alt=""
              src="/system-icon16pxminus@2x.png"
            />
          </div>
          <img
            className={styles.systemIcon24pxtrash}
            alt=""
            src="/system-icon24pxtrash@2x.png"
            onClick={onSystemIcon24pxTrashClick}
          />
        </div>
      </div>
      <div className={styles.order1}>ORDER</div>
      <div className={styles.iconFrame}>
        <img className={styles.baseIcon} alt="" src="/base@2x.png" />
        <div className={styles.iconFrameChild} />
        <div className={styles.iconFrameItem} />
        <div className={styles.iconFrameInner} />
      </div>
      <img
        className={styles.arrowArrowLeft2}
        alt=""
        src="/arrow--arrow-left-2@2x.png"
        onClick={onArrowArrowLeft2Click}
      />
      <div className={styles.orderInner} />
      <b className={styles.am}>10:35 AM</b>
      <img className={styles.wifiIcon} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon} alt="" src="/battery@2x.png" />
      <div className={styles.submitWrapper}>
        <b className={styles.submit}>Submit</b>
      </div>
    </div>
  );
};

export default ORDER;
