import { FunctionComponent, useCallback } from "react";
import {
  Button,
  TextField,
  InputAdornment,
  Icon,
  IconButton,
} from "@mui/material";
import styles from "./SignUpScreen.module.css";

const SignUpScreen: FunctionComponent = () => {
  const onButtonContainerClick = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onButtonContainer1Click = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onButtonContainer2Click = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  const onLogInClick = useCallback(() => {
    // Please sync "Login Screen" to the project
  }, []);

  return (
    <div className={styles.signUpScreen}>
      <div className={styles.signUpScreenChild} />
      <b className={styles.alreadyAMember}>{`Already a member? `}</b>
      <div className={styles.button} onClick={onButtonContainerClick}>
        <img className={styles.vectorIcon} alt="" src="/vector@2x.png" />
        <Button
          className={styles.continueWithGoogle}
          color="primary"
          variant="contained"
          href="/home-page"
        >
          Continue With Google
        </Button>
      </div>
      <div className={styles.button1} onClick={onButtonContainer1Click}>
        <img
          className={styles.socialIcoNs}
          alt=""
          src="/social-ico-ns@2x.png"
        />
        <Button
          className={styles.continueWithGoogle}
          color="primary"
          variant="contained"
          href="/home-page"
        >
          Continue With Facebook
        </Button>
      </div>
      <b className={styles.or}>OR</b>
      <div className={styles.button2} onClick={onButtonContainer2Click}>
        <Button
          className={styles.continueWithGoogle}
          color="primary"
          variant="contained"
        >
          Continue
        </Button>
      </div>
      <div className={styles.inputFrame4}>
        <TextField
          className={styles.conformPassword}
          color="primary"
          label="Conform Password"
          required={true}
          variant="standard"
        />
      </div>
      <div className={styles.inputFrame3}>
        <TextField
          className={styles.conformPassword}
          color="primary"
          label="Create Password"
          required={true}
          variant="standard"
        />
      </div>
      <div className={styles.inputFrame2}>
        <TextField
          className={styles.conformPassword}
          color="primary"
          label="Mobile number or email address"
          required={true}
          variant="standard"
        />
      </div>
      <div className={styles.inputFrame1}>
        <TextField
          className={styles.conformPassword}
          color="primary"
          label="Full Name"
          required={true}
          sx={{ width: 70 }}
          variant="standard"
        />
      </div>
      <b className={styles.welcomeToSmart}>Welcome To Smart Books</b>
      <b className={styles.signUp}>Sign up</b>
      <div className={styles.signUpScreenItem} />
      <b className={styles.am}>10:25 AM</b>
      <img className={styles.wifiIcon} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon} alt="" src="/battery@2x.png" />
      <Button
        className={styles.logIn}
        color="primary"
        variant="contained"
        href="/login-screen"
        onClick={onLogInClick}
      >
        Log in
      </Button>
    </div>
  );
};

export default SignUpScreen;
