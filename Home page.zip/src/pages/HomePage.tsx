import { FunctionComponent, useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import styles from "./HomePage.module.css";

const HomePage: FunctionComponent = () => {
  const onImage22Click = useCallback(() => {
    // Please sync "Purchasing page" to the project
  }, []);

  return (
    <div className={styles.homePage}>
      <div className={styles.homePageChild} />
      <div className={styles.buttonParent}>
        <div className={styles.button}>
          <img className={styles.vectorIcon} alt="" src="/vector@2x.png" />
          <div className={styles.home}>Home</div>
        </div>
        <div className={styles.button1}>
          <div className={styles.myOrders}>My Orders</div>
          <img className={styles.bookIcon1} alt="" src="/book-icon-1@2x.png" />
        </div>
        <div className={styles.button2}>
          <img className={styles.unionIcon} alt="" src="/union@2x.png" />
          <div className={styles.home}>Wishlist</div>
        </div>
        <div className={styles.button3}>
          <div className={styles.home}>Settings</div>
          <img className={styles.buttonChild} alt="" src="/group-16@2x.png" />
        </div>
      </div>
      <div className={styles.history}>
        <b className={styles.newArrivals}>Top Selling</b>
        <div className={styles.viewAll}>View All</div>
        <div className={styles.abandonedKingdomClaudiaContainer}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Abandoned Kingdom</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>claudia wilson</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>{`$4.29 `}</b>
              </span>
            </p>
          </span>
        </div>
        <div className={styles.frontPageNewsContainer}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b className={styles.frontPageNews1}>Front Page News</b>
            </p>
            <p className={styles.abandonedKingdom}>
              <span className={styles.span}>
                <span className={styles.sgRichmond2}>S.G. Richmond</span>
              </span>
            </p>
            <p className={styles.abandonedKingdom}>
              <span className={styles.span}>
                <b>
                  <span className={styles.span2}>$ 2.0</span>, $ 1.35
                </b>
              </span>
            </p>
          </span>
        </div>
        <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
        <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
        <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
        <div className={styles.theHypocriteWorldContainer}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>The Hypocrite World</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>Sopiha Hill</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$1.1</b>
              </span>
            </p>
          </span>
        </div>
      </div>
      <div className={styles.trending}>
        <b className={styles.newArrivals}>Trending</b>
        <div className={styles.viewAll}>View All</div>
        <div className={styles.abandonedKingdomClaudiaContainer2}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Meaning</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>Marissa Bradshaw</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$1.0</b>
              </span>
            </p>
          </span>
        </div>
        <div className={styles.frontPageNewsContainer2}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Parallel Univeese</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>Anthony Brown</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$ 1.0</b>
              </span>
            </p>
          </span>
        </div>
        <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
        <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
        <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
        <div className={styles.theHypocriteWorldContainer2}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Modern Space</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>Francicso spencer</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$1.0</b>
              </span>
            </p>
          </span>
        </div>
      </div>
      <div className={styles.newArrival}>
        <b className={styles.newArrivals}>New Arrivals</b>
        <div className={styles.viewAll}>View All</div>
        <div className={styles.abandonedKingdomClaudiaContainer}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Abandoned Kingdom</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>claudia wilson</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$4.63</b>
              </span>
            </p>
          </span>
        </div>
        <div className={styles.frontPageNewsContainer2}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>Front Page News</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>S.G. Richmond</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$ 1.0</b>
              </span>
            </p>
          </span>
        </div>
        <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
        <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
        <img
          className={styles.image2Icon2}
          alt=""
          src="/image-2@2x.png"
          onClick={onImage22Click}
        />
        <div className={styles.theHypocriteWorldContainer}>
          <span className={styles.abandonedKingdomClaudiaContainer1}>
            <p className={styles.abandonedKingdom}>
              <b>The Hypocrite World</b>
            </p>
            <p className={styles.claudiaWilson}>
              <span className={styles.span}>
                <span>Sopiha Hill</span>
              </span>
            </p>
            <p className={styles.p}>
              <span className={styles.span}>
                <b>$1.0</b>
              </span>
            </p>
          </span>
        </div>
      </div>
      <div className={styles.input}>
        <div className={styles.vectorParent}>
          <img className={styles.vectorIcon1} alt="" src="/vector@2x.png" />
          <TextField
            className={styles.book}
            color="primary"
            label="Search"
            variant="standard"
          />
        </div>
        <img className={styles.inputChild} alt="" src="/group-21@2x.png" />
      </div>
      <b className={styles.hiBablu}>Hi, Bablu</b>
      <img className={styles.iconFrame} alt="" src="/icon-frame@2x.png" />
      <img
        className={styles.ecommerceShoppingCardAdd}
        alt=""
        src="/ecommerce--shopping-card-add@2x.png"
      />
      <img className={styles.homePageItem} alt="" src="/ellipse-1@2x.png" />
      <div className={styles.homePageInner} />
      <img className={styles.wifiIcon} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon} alt="" src="/battery@2x.png" />
      <b className={styles.am}>10:30 AM</b>
    </div>
  );
};

export default HomePage;
