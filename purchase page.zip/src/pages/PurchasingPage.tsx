import { FunctionComponent, useCallback } from "react";
import styles from "./PurchasingPage.module.css";

const PurchasingPage: FunctionComponent = () => {
  const onBUTTONContainerClick = useCallback(() => {
    // Please sync "ORDER" to the project
  }, []);

  const onBUTTONContainer1Click = useCallback(() => {
    // Please sync "ORDER" to the project
  }, []);

  const onFrameIconClick = useCallback(() => {
    // Please sync "ORDER" to the project
  }, []);

  const onArrowArrowLeft2Click = useCallback(() => {
    // Please sync "Home Page" to the project
  }, []);

  return (
    <div className={styles.purchasingPage}>
      <div className={styles.button} onClick={onBUTTONContainerClick}>
        <b className={styles.buyNow}>Buy Now</b>
      </div>
      <div className={styles.button1} onClick={onBUTTONContainer1Click}>
        <b className={styles.buyNow}>Add To Cart</b>
      </div>
      <b className={styles.thereAreMany}>
        {" "}
        There are many variations of passages of Lorem Ipsum available, but the
        majority have suffered alteration in some form, by injected humour, or
        randomised words which don't look even slightly believable. If you are
        going to use a passage of Lorem Ipsum, you need to be sure there isn't
        anything embarrassing hidden in the middle of text. All the Lorem Ipsum
        generators on the Internet tend to repeat predefined chunks as
        necessary, making this the first true generator on the Internet.
      </b>
      <div className={styles.purchasingPageChild} />
      <div className={styles.starParent}>
        <img className={styles.groupChild} alt="" src="/star-1@2x.png" />
        <img className={styles.groupItem} alt="" src="/star-1@2x.png" />
        <img className={styles.groupInner} alt="" src="/star-1@2x.png" />
        <img className={styles.starIcon} alt="" src="/star-1@2x.png" />
        <b className={styles.b}>4/5</b>
      </div>
      <div className={styles.abandonedKingdomClaudiaContainer}>
        <p className={styles.abandonedKingdom}>
          <b>Abandoned Kingdom</b>
        </p>
        <p className={styles.claudiaWilson}>Claudia Wilson</p>
      </div>
      <img
        className={styles.purchasingPageItem}
        alt=""
        src="/rectangle-93@2x.png"
      />
      <b className={styles.b1}>
        <span>$</span>
        <span className={styles.span}>4.63</span>
      </b>
      <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
      <img
        className={styles.purchasingPageInner}
        alt=""
        src="/frame-4@2x.png"
        onClick={onFrameIconClick}
      />
      <div className={styles.iconFrame}>
        <img className={styles.baseIcon} alt="" src="/base@2x.png" />
        <div className={styles.iconFrameChild} />
        <div className={styles.iconFrameItem} />
        <div className={styles.iconFrameInner} />
      </div>
      <img
        className={styles.arrowArrowLeft2}
        alt=""
        src="/arrow--arrow-left-2@2x.png"
        onClick={onArrowArrowLeft2Click}
      />
      <div className={styles.rectangleDiv} />
      <b className={styles.am}>10:30 AM</b>
      <img className={styles.wifiIcon} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon} alt="" src="/battery@2x.png" />
    </div>
  );
};

export default PurchasingPage;
