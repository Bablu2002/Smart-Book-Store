import { FunctionComponent, useCallback } from "react";
import styles from "./Payment.module.css";

const Payment: FunctionComponent = () => {
  const onButtonContainerClick = useCallback(() => {
    // Please sync "success" to the project
  }, []);

  const onArrowArrowLeft2Click = useCallback(() => {
    // Please sync "ORDER" to the project
  }, []);

  return (
    <div className={styles.payment}>
      <div className={styles.button} onClick={onButtonContainerClick}>
        <b className={styles.pay}>Pay</b>
      </div>
      <div className={styles.mode}>
        <b className={styles.paymentMode}>Payment Mode</b>
        <div className={styles.cards}>Cards</div>
        <div className={styles.credit}>
          <div className={styles.creditCard}>Credit card</div>
          <img className={styles.creditChild} alt="" src="/group-24@2x.png" />
        </div>
        <div className={styles.debit}>
          <div className={styles.creditCard}>Debit card</div>
          <img className={styles.creditChild} alt="" src="/group-24@2x.png" />
        </div>
        <div className={styles.frameParent}>
          <div className={styles.cardNumberParent}>
            <b className={styles.cardNumber}>Card Number</b>
            <div className={styles.input}>
              <div className={styles.enterCardNumber}>Enter Card Number</div>
            </div>
          </div>
          <div className={styles.frameGroup}>
            <div className={styles.expirationDateParent}>
              <b className={styles.expirationDate}>Expiration Date</b>
              <div className={styles.input1}>
                <div className={styles.enterCardNumber}>Expiration Date</div>
              </div>
            </div>
            <div className={styles.cvvParent}>
              <b className={styles.cvv}>CVV</b>
              <div className={styles.input2}>
                <div className={styles.enterCardNumber}>Security Code</div>
              </div>
            </div>
          </div>
          <div className={styles.cardNumberParent}>
            <b className={styles.cardHolder}>Card Holder</b>
            <div className={styles.input}>
              <div className={styles.enterCardNumber}>Enter Number</div>
            </div>
          </div>
        </div>
        <div className={styles.upiWrapper}>
          <div className={styles.upi}>UPI</div>
        </div>
        <div className={styles.input4}>
          <div className={styles.creditCard}>Paytm</div>
        </div>
        <div className={styles.input5}>
          <div className={styles.creditCard}>Google pay</div>
        </div>
        <div className={styles.input4}>
          <div className={styles.creditCard}>Phone pay</div>
        </div>
      </div>
      <div className={styles.checkOut}>Check Out</div>
      <div className={styles.iconFrame}>
        <img className={styles.baseIcon} alt="" src="/base@2x.png" />
        <div className={styles.iconFrameChild} />
        <div className={styles.iconFrameItem} />
        <div className={styles.iconFrameInner} />
      </div>
      <img
        className={styles.arrowArrowLeft2}
        alt=""
        src="/arrow--arrow-left-2@2x.png"
        onClick={onArrowArrowLeft2Click}
      />
      <div className={styles.paymentChild} />
      <b className={styles.am}>10:40 AM</b>
      <img className={styles.wifiIcon} alt="" src="/wifi@2x.png" />
      <img className={styles.signalIcon} alt="" src="/signal@2x.png" />
      <img className={styles.batteryIcon} alt="" src="/battery@2x.png" />
    </div>
  );
};

export default Payment;
